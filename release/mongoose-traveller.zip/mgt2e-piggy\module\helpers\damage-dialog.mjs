import {hasTrait} from "../helpers/dice-rolls.mjs";
import {dialogBrassClasses} from "../helpers/dialog-theme.mjs";

export class MgT2DamageDialog extends Application {
    static get defaultOptions() {
        const options = super.defaultOptions;
        options.template = "systems/mgt2e-piggy/templates/damage-dialog.html";
        options.width = "auto";
        options.height = "auto";
        options.title = game.i18n.localize("MGT2.DamageDialog.Title");
        options.shareable = true;
        options.popOut = true;
        options.resizable = true;
        options.classes = [...options.classes, ...dialogBrassClasses()];

        return options;
    }

    constructor(actor, damage, damageOptions) {
        super();

        this.actor = actor;
        this.damageOptions = damageOptions;
        const data = actor.system;

        damageOptions.effect = parseInt(damageOptions.effect);
        this.damage = parseInt(damageOptions.damage) + ((damageOptions.effect > 0)?damageOptions.effect:0);
        this.ap = damageOptions.ap?damageOptions.ap:0;
        this.laser = damageOptions.damageType;
        this.stun = hasTrait(damageOptions.traits, "stun");
        this.data = data;
        this.armour = damageOptions.armour?damageOptions.armour:0;
        if (damageOptions.finalArmour !== undefined && damageOptions.finalArmour !== this.armour) {
            this.armour = `${this.armour} (${damageOptions.finalArmour})`;
        }
        this.wounds = "";
        this.armourText = damageOptions.armourText;

        this.actualDamage = damage;
        if (!data.damage) {
            // This is a creature or NPC. Shouldn't be called.
            data.hits.damage += this.actualDamage;
            this.actor.update({ "data.damage": this.data.damage });
            return;
        }
        this.radiationDamage = 0;
        this.armourRads = damageOptions.armourRads?damageOptions.armourRads:0;
        this.actualRadiation = 0;
        if (damageOptions.radiation > 0) {
            this.radiationDamage = damageOptions.radiation;
            this.actualRadiation = this.radiationDamage - this.armourRads;
        }
        this.ablatItem = actor.findAblatTarget(damageOptions);

        this.DMG_STR = parseInt(data.damage.STR.value);
        this.DMG_DEX = parseInt(data.damage.DEX.value);
        this.DMG_END = parseInt(data.damage.END.value);

        this.STR = parseInt(data.characteristics.STR.value) - this.DMG_STR;
        this.DEX = parseInt(data.characteristics.DEX.value) - this.DMG_DEX;
        this.END = parseInt(data.characteristics.END.value) - this.DMG_END;

        // Traveller damage rules: END must be depleted before STR or DEX can take damage.
        this.endDepleted = this.END <= 0;

        // For historical reasons 'laser' is the damage type.
        if (data.characteristics[this.laser]) {
            this.XXX = parseInt(data.characteristics[this.laser].value);
            this.XXX_VALUE = this.XXX;
            if (data.damage[this.laser]) {
                this.DMG_XXX = parseInt(data.damage[this.laser].value);
            } else {
                this.DMG_XXX = 0;
                data.damage[this.laser] = {
                    value: 0
                };
            }
            this.XXX -= this.DMG_XXX;
            this.XXX_VALUE = this.XXX;
        }

        let totalEND = parseInt(data.characteristics.END.value);
        if (this.actualDamage === 0) {
            this.wounds = "-";
            this.woundsEffect = "";
        } else if (this.stun) {
            this.wounds = game.i18n.localize("MGT2.DamageWound.Stun");
            this.woundsEffect = game.i18n.localize("MGT2.DamageWound.StunEffect");
        } else if (this.actualDamage < parseInt(totalEND / 2)) {
            this.wounds = game.i18n.localize("MGT2.DamageWound.Minor");
            this.woundsEffect = game.i18n.localize("MGT2DamageWound.MinorEffect");
        } else if (this.actualDamage <= totalEND) {
            this.wounds = game.i18n.localize("MGT2.DamageWound.Major");
            this.woundsEffect = game.i18n.localize("MGT2.DamageWound.MajorEffect");
        } else if (this.actualDamage < totalEND * 2) {
            this.wounds = game.i18n.localize("MGT2.DamageWound.Severe");
            this.woundsEffect = game.i18n.localize("MGT2.DamageWound.SevereEffect");
        } else if (this.actualDamage < totalEND * 3) {
            this.wounds = game.i18n.localize("MGT2.DamageWound.Crippling");
            this.woundsEffect = game.i18n.localize("MGT2.DamageWound.CripplingEffect");
        } else if (this.actualDamage < totalEND * 4) {
            this.wounds = game.i18n.localize("MGT2.DamageWound.Critical");
            this.woundsEffect = game.i18n.localize("MGT2.DamageWound.CriticalEffect");
        } else if (this.actualDamage < totalEND * 5) {
            this.wounds = game.i18n.localize("MGT2.DamageWound.Mortal");
            this.woundsEffect = game.i18n.localize("MGT2.DamageWound.MortalEffect");
        } else {
            this.wounds = game.i18n.localize("MGT2.DamageWound.Devastating");
            this.woundsEffect = game.i18n.localize("MGT2.DamageWound.DevastatingEffect");
        }

        this.remainingDamage = this.actualDamage;

    }

    getData() {
        console.log(this.actor);
        console.log(this.actor.token);
        return {
            "actor": this.actor,
            "data": this.data,
            "damage": this.damage,
            "ap": this.ap,
            "laser": this.laser,
            "stun": this.stun,
            "armour": this.armour,
            "actualDamage": this.actualDamage,
            "remainingDamage": this.remainingDamage,
            "STR": this.STR,
            "DEX": this.DEX,
            "END": this.END,
            "endDepleted": this.endDepleted,
            "XXX": this.XXX,
            "XXX_VALUE": this.XXX_VALUE,
            "DMG_STR": this.DMG_STR,
            "DMG_DEX": this.DMG_DEX,
            "DMG_END": this.DMG_END,
            "DMG_XXX": this.DMG_XXX,
            "wounds": this.wounds,
            "armourText": this.armourText,
            "woundsEffect": this.woundsEffect,
            "radiation": this.radiationDamage,
            "actualRadiation": this.actualRadiation,
            "armourRads": this.armourRads,
            "ablatItem": this.ablatItem,
            "useAblat": true,
            "playerRequestName": this.damageOptions.playerRequestName
        }
    }

    activateListeners(html) {
        super.activateListeners(html);
        const roll = html.find("button[class='damageDone']");
        roll.on("click", event => this.doneClick(event, html));

        html.find(".apply-button").click(ev => {
           this.applyDamage(ev, html);
        });
    }

    applyDamage(event, html) {
        let cha = event.currentTarget.dataset.cha;

        let currentDmg = this.getIntValue(html, ".DMG_" + cha);
        let currentScore = this.getIntValue(html, ".VAL_" + cha);
        let maxScore = this.getIntValue(html, this.data.characteristics[cha].value);

        if (this.stun) {
            currentDmg += this.remainingDamage;
            currentScore -= this.remainingDamage;
            this.remainingDamage = 0;
        } else if (this.remainingDamage <= currentScore) {
            currentDmg += this.remainingDamage;
            currentScore -= this.remainingDamage;
            this.remainingDamage = 0;
        } else {
            let applyDmg = currentScore;
            currentDmg += applyDmg;
            currentScore -= applyDmg;
            this.remainingDamage -= applyDmg;
        }

        this.setIntValue(html, ".DMG_"+cha, currentDmg);
        this.setIntValue(html, ".VAL_"+cha, currentScore);
        this.setIntValue(html, ".remaining", this.remainingDamage);

        if (cha === "END") {
            this.updateApplyButtonStates(html);
        }
    }

    /**
     * END must be depleted before STR or DEX can take damage. Called after
     * END changes, since that's the only thing that can flip this.
     */
    updateApplyButtonStates(html) {
        const endDepleted = this.getIntValue(html, ".VAL_END") <= 0;
        const title = endDepleted ? "" : game.i18n.localize("MGT2.DamageDialog.EndFirst");

        for (const cha of ["STR", "DEX"]) {
            const button = html.find(`.apply-button[data-cha='${cha}']`);
            button.prop("disabled", !endDepleted);
            button.attr("title", title);
        }
    }

    getIntValue(html, field) {
        if (html.find(field) && html.find(field)[0] && html.find(field)[0].value) {
            let v = html.find(field)[0].value;
            if (v === "" || !v) {
                return 0;
            }
            return parseInt(v);
        }
        return 0;
    }

    setIntValue(html, field, value) {
        if (html.find(field) && html.find(field)[0] && html.find(field)[0].value) {
            html.find(field)[0].value = value;
        }
    }

    async doneClick(event, html) {
        event.preventDefault();

        // Guard against a double-click (or a re-render re-binding the Done
        // button) firing this twice - applyActualDamageToTraveller isn't
        // awaited below, so a second overlapping call before the first has
        // finished writing its effects would create duplicate Dead/
        // Unconscious/Injured effects, same as the original Vacc Suit bug.
        if (this._doneClicked) {
            return;
        }
        this._doneClicked = true;

        let str = Math.max(0, this.getIntValue(html, ".DMG_STR") - this.DMG_STR);
        let dex = Math.max(0, this.getIntValue(html, ".DMG_DEX") - this.DMG_DEX);
        let end = Math.max(0, this.getIntValue(html, ".DMG_END") - this.DMG_END);
        let xxx = null;
        let damage = 0;
        if (this.XXX) {
            xxx = Math.max(0, this.getIntValue(html, ".DMG_XXX") - this.DMG_XXX);
            this.damageOptions.characteristics = { };
            this.damageOptions.characteristics[this.laser] = xxx;
            this.damageOptions.directChaDamage = true;
        } else {
            damage = this.actualDamage;

            this.damageOptions.characteristics = {
                "STR": str,
                "DEX": dex,
                "END": end
            }
            this.damageOptions.actualRadiation = this.actualRadiation;
        }
        if (this.ablatItem && html.find(".useAblat")[0]?.checked) {
            this.damageOptions.ablatItemId = this.ablatItem._id;
        }
        await this.actor.applyActualDamageToTraveller(damage, this.damageOptions);
        this.close();
    }

    async close(options) {
        this.damageOptions.onApplied?.();
        return super.close(options);
    }

    async _updateObject(event, formData) {
        console.log("_updateObject:");
    }
}

window.MgT2DamageDialog = MgT2DamageDialog;
